import http.server
import socketserver
import webbrowser
import os
import sys
import signal

PORT = 8080

# Graceful shutdown handling
def signal_handler(sig, frame):
    print('\n👋 Server shutting down...')
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=os.getcwd(), **kwargs)
    
    def do_GET(self):
        # Route root to index.html
        if self.path == '/':
            self.path = '/index.html'
        elif self.path == '/style.css':
            self.path = '/style.css'
        elif self.path == '/script.js':
            self.path = '/script.js'
        
        # Try to serve the file
        try:
            super().do_GET()
        except BrokenPipeError:
            pass  # Client disconnected, ignore
        except ConnectionAbortedError:
            pass  # Client disconnected, ignore
    
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()
    
    def log_message(self, format, *args):
        # Suppress default log messages
        pass

def check_prerequisites():
    """Check if all required files exist"""
    print("🔍 Checking prerequisites...")
    
    required_files = ['index.html', 'style.css', 'script.js']
    missing_files = []
    
    for file in required_files:
        if not os.path.exists(file):
            missing_files.append(file)
    
    if missing_files:
        print("❌ Missing files:", missing_files)
        print("📁 Current directory:", os.getcwd())
        print("📁 Files in directory:", os.listdir('.'))
        return False
    
    print("✅ All required files found")
    return True

def start_server():
    print(f"📁 Serving from: {os.getcwd()}")
    print(f"🌐 Server will start on: http://localhost:{PORT}")
    
    if not check_prerequisites():
        print("❌ Cannot start server due to missing files")
        return
    
    try:
        with socketserver.TCPServer(("", PORT), Handler) as httpd:
            httpd.allow_reuse_address = True
            print(f"🚀 Frontend server running at http://localhost:{PORT}")
            print("📡 WebSocket will connect to: ws://localhost:8000/ws")
            print("⚡ Make sure FastAPI backend is running on port 8000")
            print("\n💡 Controls:")
            print("  • Click 'Test Attack' buttons to simulate attacks")
            print("  • ML model will detect anomalies")
            print("  • 5-second countdown will start")
            print("  • Safe mode activates automatically")
            print("\n🔄 Press Ctrl+C to stop server\n")
            
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                print("\n👋 Server stopped by user")
                httpd.shutdown()
                sys.exit(0)
                
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"❌ Port {PORT} is already in use")
            print("💡 Try: netstat -ano | findstr :8080")
            print("💡 Or change PORT in http_server.py")
        else:
            print(f"❌ Server error: {e}")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")

if __name__ == "__main__":
    # Try to open browser
    try:
        webbrowser.open(f'http://localhost:{PORT}')
        print("🌐 Opening browser...")
    except:
        print(f"🌐 Please open manually: http://localhost:{PORT}")
    
    # Start server
    start_server()