from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
import asyncio
from datetime import datetime

app = FastAPI()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

system_state = "NORMAL"
anomaly_score = 0.15
connections = []

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    connections.append(websocket)
    
    # Send initial state
    await websocket.send_json({
        "type": "INITIAL_STATE",
        "state": system_state,
        "anomaly_score": anomaly_score
    })
    
    try:
        while True:
            data = await websocket.receive_json()
            
            if data.get("type") == "TELEMETRY":
                # Echo back
                await websocket.send_json({
                    "type": "TELEMETRY_ACK",
                    "state": system_state,
                    "timestamp": datetime.now().isoformat()
                })
                
            elif data.get("type") == "PING":
                await websocket.send_json({
                    "type": "PONG",
                    "state": system_state
                })
                
    except:
        connections.remove(websocket)

@app.post("/api/simulate-attack")
async def simulate_attack():
    global system_state, anomaly_score
    
    if system_state == "SAFE_MODE":
        return JSONResponse({
            "status": "error",
            "message": "Already in safe mode"
        })
    
    # Simulate attack detection
    system_state = "ATTACK_DETECTED"
    anomaly_score = 0.85
    
    # Broadcast to all connected clients
    for connection in connections:
        try:
            await connection.send_json({
                "type": "ATTACK_DETECTED",
                "anomaly_score": anomaly_score,
                "countdown": 5,
                "message": "ML detected anomaly! Safe mode in 5s"
            })
        except:
            pass
    
    # After 5 seconds, activate safe mode
    async def activate_safe_mode():
        await asyncio.sleep(5)
        global system_state
        system_state = "SAFE_MODE"
        
        for connection in connections:
            try:
                await connection.send_json({
                    "type": "SYSTEM_STATE",
                    "state": system_state,
                    "message": "SAFE MODE ACTIVATED"
                })
            except:
                pass
    
    asyncio.create_task(activate_safe_mode())
    
    return JSONResponse({
        "status": "success",
        "message": "Attack simulation started",
        "anomaly_score": anomaly_score,
        "state": system_state
    })

@app.post("/api/reset-system")
async def reset_system():
    global system_state, anomaly_score
    system_state = "NORMAL"
    anomaly_score = 0.15
    
    for connection in connections:
        try:
            await connection.send_json({
                "type": "SYSTEM_RESET",
                "state": "NORMAL",
                "message": "System reset to normal mode"
            })
        except:
            pass
    
    return JSONResponse({
        "status": "success",
        "message": "System reset to NORMAL"
    })

@app.get("/api/system-state")
async def get_system_state():
    return JSONResponse({
        "system_state": system_state,
        "anomaly_score": anomaly_score,
        "reconstruction_error": 0.084,
        "threshold": 0.70,
        "safe_mode_countdown": None,
        "attack_timeline": [],
        "last_update": datetime.now().isoformat()
    })

@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "state": system_state}

if __name__ == "__main__":
    print("🚀 Starting TEST backend server...")
    print("🌐 WebSocket: ws://localhost:8000/ws")
    print("🔧 API: http://localhost:8000/docs")
    print("\n💡 Use this for testing if main backend fails")
    uvicorn.run(app, host="0.0.0.0", port=8000)