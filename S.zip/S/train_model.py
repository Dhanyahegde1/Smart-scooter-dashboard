import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import joblib
from model import LSTMAutoencoder
import os

def generate_normal_riding_data(num_samples=10000):
    """Generate synthetic normal riding data"""
    np.random.seed(42)
    
    # Features: speed, acceleration_x, acceleration_y, acceleration_z, lat_change, lon_change
    data = []
    
    for _ in range(num_samples):
        # Normal riding patterns
        speed = np.random.uniform(20, 60)  # 20-60 km/h
        accel_x = np.random.normal(0, 0.5)
        accel_y = np.random.normal(0, 0.3)
        accel_z = np.random.normal(9.8, 0.2)  # Gravity with slight variations
        lat_change = np.random.uniform(-0.001, 0.001)
        lon_change = np.random.uniform(-0.001, 0.001)
        
        data.append([speed, accel_x, accel_y, accel_z, lat_change, lon_change])
    
    return np.array(data)

def prepare_sequences(data, timesteps=10):
    """Convert data to sequences for LSTM"""
    sequences = []
    for i in range(len(data) - timesteps + 1):
        sequences.append(data[i:i+timesteps])
    return np.array(sequences)

def train_model():
    print("Generating training data...")
    normal_data = generate_normal_riding_data(5000)
    
    print("Scaling data...")
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(normal_data)
    
    print("Creating sequences...")
    sequences = prepare_sequences(scaled_data, timesteps=10)
    
    print(f"Training data shape: {sequences.shape}")
    
    print("Training LSTM Autoencoder...")
    model = LSTMAutoencoder(timesteps=10, n_features=6, latent_dim=32)
    model.build_model()
    model.scaler = scaler
    
    print(f"Training on {len(sequences)} sequences...")
    model.fit(sequences, epochs=30, batch_size=32)
    
    print(f"Threshold set to: {model.threshold:.4f}")
    
    print("Saving model...")
    os.makedirs('models', exist_ok=True)
    model.save_model()
    joblib.dump(scaler, 'models/scaler.pkl')
    
    print("Model training completed!")
    return model

if __name__ == "__main__":
    train_model()